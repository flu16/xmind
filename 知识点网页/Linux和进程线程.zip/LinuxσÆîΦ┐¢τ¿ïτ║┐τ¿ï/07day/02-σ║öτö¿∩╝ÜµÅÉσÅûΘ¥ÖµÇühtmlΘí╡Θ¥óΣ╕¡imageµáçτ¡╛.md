# 应用：提取静态html页面中image标签
